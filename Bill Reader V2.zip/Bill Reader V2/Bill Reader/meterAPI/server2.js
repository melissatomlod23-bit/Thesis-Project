const express = require('express');
const bodyParser = require('body-parser');
const sql = require('mssql');
const app = express();

app.use(bodyParser.json());

const dbConfig = {
user: 'sa', //username of mssql server
    password: 'p@ssw0rd', //password of server
    server: 'SIEGMUND-PC', // or use your computer's IP
    port: 1433,
    database: 'BillReader', //database name
    options: { 
	//encrypt: false, 
	trustServerCertificate: true }
	};

app.post('/api/sensordata2', async (req, res) => {
    const { Watt, Voltage } = req.body;

    if (typeof Watt === 'undefined' || typeof Voltage === 'undefined') {
        return res.status(400).send('Watt and Voltage are required');
    }

    try {
        // attempt to connect to the database
        await sql.connect(dbConfig);

        // insert data into the database
        await sql.query`INSERT INTO SensorData2 (Watt, Voltage) VALUES (${Watt}, ${Voltage})`;

        // send success response
        res.send('Data inserted successfully');
    } catch (err) {
        // log the actual error message for debugging
        console.error('Database error:', err);

        res.status(500).send('Database error: ' + err.message);
    }
});

app.listen(3000, () => console.log('API running on port 3000'));
