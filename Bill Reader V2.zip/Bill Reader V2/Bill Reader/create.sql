USE [DhezshamiDB] --use your database name
GO

/****** Object:  Table [dbo].[SensorData]    Script Date: 21/05/2025 4:30:25 pm ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[SensorData](
	[Id] [int] IDENTITY(1,1) NOT NULL,
	[Watt] [float] NULL,
	[Voltage] [float] NULL,
	[Timestamp] [datetime] NULL,
PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[SensorData] ADD  DEFAULT (getdate()) FOR [Timestamp]
GO

